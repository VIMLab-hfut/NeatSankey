## website

The user data comes from online investigating

And the WebSite which used to collect data has been put in the folder "User_Study_Web"

## data

The data that we collect has been put in the folder "User_Study_Data"

# supp.pdf

To furtherly present the work we had down, we put more details including more layout results, metrics and so on